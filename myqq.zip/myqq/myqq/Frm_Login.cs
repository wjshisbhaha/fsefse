﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace myqq
{
    public partial class Frm_Login : Form
    {
        public Frm_Login()
        {
            InitializeComponent();
        }

        DataOperator dataoper = new DataOperator();

        private bool ValidateInput()
        {
            if (txtID.Text.Trim() == "")
            {
                MessageBox.Show("请输入登录账号", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtID.Focus();
                return false;
            }
            else if (int.Parse(txtID.Text.Trim()) > 65535)
            {
                MessageBox.Show("请输入账号", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtPwd.Focus();
                return false;
            }
            else if (txtID.Text.Length > 5 && txtPwd.Text.Trim() == "")
            {
                MessageBox.Show("请输入密码", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtPwd.Focus();
                return false;
            }
            return true;
        
        
        }
        

        private void Frm_Login_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void txtID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == '\r' || e.KeyChar == '\b')
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void pboxLogin_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                string sql = "select count(*) from tb_User where ID = " + int.Parse(txtID.Text.Trim()) + " and Pwd = '" + txtPwd.Text.Trim() + "'";
                int num = dataoper.ExecSql(sql);
                if (num == 1)
                {
                    PublicClass.LoginID = int.Parse(txtID.Text.Trim());
                    if (cboxRemember.Checked)
                    {
                        dataoper.ExecSQLResult("update tb_User set  Remember = 1 where ID=" + int.Parse(txtID.Text.Trim()));
                        if (cboxAutoLogin.Checked)
                            dataoper.ExecSQLResult("update tb_User set  AutoLogin = 1 where ID=" + int.Parse(txtID.Text.Trim()));
                    }
                    else
                    {
                        dataoper.ExecSQLResult("update tb_User set  Remember = 0 where ID=" + int.Parse(txtID.Text.Trim()));
                        dataoper.ExecSQLResult("update tb_User set  AutoLogin = 0 where ID=" + int.Parse(txtID.Text.Trim()));
                    }
                    dataoper.ExecSQLResult("update tb_User set  Flag = 1  where ID=" + int.Parse(txtID.Text.Trim()));
                    Frm_Main frmmain = new Frm_Main();
                    frmmain.Show();
                    this.Visible = false;
                }
                else
                {
                    MessageBox.Show("输入的用户名或者密码错误", "登录提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    
                
                }

            
            
            }
        }

        private void txtPwd_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
                pboxLogin_Click(sender,e);
        }

        private void cboxRemember_CheckedChanged(object sender, EventArgs e)
        {
            if (!cboxRemember.Checked)
                cboxAutoLogin.Checked = false;

        }
    }
}
