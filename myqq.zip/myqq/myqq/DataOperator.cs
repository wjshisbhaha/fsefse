﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Google.Protobuf.WellKnownTypes;
using MySql.Data.MySqlClient;
namespace myqq
{
    internal class DataOperator
    {
       private static string connstr  = "server  = 192.168.76.155; user = wjx;password = 200312wj;database = test;";
       public static MySqlConnection conn = new MySqlConnection(connstr);

       public int ExecSql(string sql)
       {
            MySqlCommand command = new MySqlCommand(sql, conn);
            if (conn.State == System.Data.ConnectionState.Closed)
                conn.Open();
            int   num = Convert.ToInt32(command.ExecuteScalar());
            conn.Close();
            return num;
       }
        public int ExecSQLResult(string sql)
        {
            MySqlCommand command = new MySqlCommand(sql, conn);
            if (conn.State == System.Data.ConnectionState.Closed)
                conn.Open();
            int result = command.ExecuteNonQuery();
            conn.Close();
            return result;
        }
    }
}
