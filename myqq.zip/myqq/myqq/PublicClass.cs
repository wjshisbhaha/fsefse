﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myqq
{
    internal class PublicClass
    {
        public static int LoginID; //记录当前登录用户的Id
    }
}
